--Userview
--1
create view Customer1998
	as select o.CustomerID, c.CompanyName, od.ProductID, p.ProductName
	from Orders o, Customers c, [Order Details] od, Products p
	where o.OrderID = od.OrderID and c.CustomerID = o.CustomerID and od.ProductID = p.ProductID
	and year(o.OrderDate) = '1998'

--2
select cus.CompanyName, cus.ProductName, su.CompanyName
from Customer1998 cus, Suppliers su, Products p
where su.SupplierID = p.SupplierID and p.ProductID = cus.ProductID

--3
select CompanyName, count(*) from Customer1998
group by CompanyName

--4a
create view TotalBiz as
select o.CustomerID, sum(od.Quantity * od.UnitPrice) as Amount from [Order Details] od, Orders o
where od.OrderID = o.OrderID
	group by o.CustomerID

--4b
select avg(Amount) from TotalBiz