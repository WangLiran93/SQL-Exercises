--1
create table MemberCategories
(MemberCategory nvarchar(2) not null,
MemberCatDescription nvarchar(200) not null,
primary key (MemberCategory))

--2
insert into MemberCategories (MemberCategory,MemberCatDescription)
values('A','Class A Members')
insert into MemberCategories (MemberCategory,MemberCatDescription)
values('B','Class B Members')
insert into MemberCategories (MemberCategory,MemberCatDescription)
values('C','Class C Members')

--3
create table GoodCustomers(CustomerName nvarchar(50) not null, 
Address nvarchar(65), PhoneNumber nvarchar(9) not null, 
MemberCategory nvarchar(2),
primary key (CustomerName, PhoneNumber), 
foreign key (MemberCategory) references MemberCategories(MemberCategory) on delete cascade)

--4
insert into GoodCustomers(CustomerName,PhoneNumber,MemberCategory)
select CustomerName, PhoneNumber,MemberCategory from Customers
where MemberCategory in ('A','B')

--5
insert into GoodCustomers(CustomerName,PhoneNumber,MemberCategory)
values('Tracy Tan','736572','B')

--6
insert into GoodCustomers(CustomerName,Address,PhoneNumber,MemberCategory)
values('Grace Leong','15 Bukit Purmei Road, Singapore 0904','278865','A')

--7
insert into GoodCustomers(CustomerName,Address,PhoneNumber,MemberCategory)
values('Lynn Lim','15 Bukit Purmei Road, Singapore 0904','278865','P')

--8
update GoodCustomers set Address = '22 Bukit Purmei Road, Singapore 0904'
where CustomerName = 'Grace Leong'

--9
update GoodCustomers set MemberCategory = 'B'
where CustomerName in 
(select CustomerName from Customers where CustomerID = 5108)

--10
delete from GoodCustomers where CustomerName = 'Grace Leong'

--11
delete from GoodCustomers where MemberCategory = 'B'

--12
alter table GoodCustomers add FaxNumber nvarchar(25)

--13
alter table GoodCustomers alter column Address nvarchar(80)

--14
alter table GoodCustomers add ICNumber nvarchar(10)

--15
create unique index ICIndex on GoodCustomers(ICNumber)

--16
create index Fax on GoodCustomers(FaxNumber)

--17
drop index Fax on GoodCustomers

--18
alter table GoodCustomers drop column FaxNumber

--19
delete from GoodCustomers

--20
drop table GoodCustomers