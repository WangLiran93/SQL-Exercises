--17
select CustomerID, COUNT(*) as NumOfOrders from Orders group by CustomerID

--18
select c.CompanyName, o.OrderID from Customers c, Orders o
where c.CustomerID = o.CustomerID and o.CustomerID = 'BONAP'

--19a
select count(*) as OrderMade, o.CustomerID, c.CompanyName
from Customers c , Orders o 
where o.CustomerID = c.CustomerID
group by o.CustomerID, c.CompanyName
having count(*) > 10 
order by OrderMade desc

--19b
select count(*) as OrderMade, o.CustomerID, c.CompanyName
from Customers c , Orders o 
where o.CustomerID = c.CustomerID and o.CustomerID = 'BONAP'
group by o.CustomerID, c.CompanyName

--19c
select count(*) as OrderMade, o.CustomerID, c.CompanyName
from Customers c , Orders o 
where o.CustomerID = c.CustomerID
group by o.CustomerID, c.CompanyName
having count(*) > (select count(*) from Orders where CustomerID = 'BONAP' )

--20a
select CategoryID as ProductCode, ProductName from Products 
where CategoryID between 1 and 2

--20b
select p.CategoryID as ProductCode, p.ProductName from Products p, Categories c 
where p.CategoryID = c.CategoryID and c.CategoryName in ('Beverages','Condiments')
--or
select * from products where CategoryID in
(select CategoryID from Categories where CategoryName= 'Beverages' or CategoryName= 'Condiments' );

--21a
select count(*) TotalEmployees from Employees

--21b
select count(*) TotalEmployeesfromUSA from Employees where Country = 'USA'

--22
select * from Orders 
where ShipVia in 
	(select ShipperID  from Shippers where CompanyName = 'United Package')
	and EmployeeID in
	(select EmployeeID from Employees where Title = 'Sales Representative')

--23
select staff.FirstName+' '+staff.LastName as FullName, 
manager.FirstName+' '+manager.LastName as Manager
from Employees staff, Employees manager where staff.ReportsTo = manager.EmployeeID

--24
select top 5  p.ProductName, o.UnitPrice * o.Quantity * o.Discount as DiscountedProduct 
from Products p, [Order Details] o
where p.ProductID = o.ProductID order by DiscountedProduct desc

--25
select CompanyName from Customers where City not in (select City from Suppliers)

--26
select distinct City from Customers where City in (select distinct City from Suppliers)
--OR
select distinct Customers.City from Customers, Suppliers where Customers.City	= Suppliers.City

--27a
select CompanyName, Address,Phone from Customers  union 
select CompanyName,Address,Phone from Suppliers

--27b
select CompanyName, Address,Phone from Customers  union 
select CompanyName,Address,Phone from Suppliers union
select CompanyName, NULL as Address, Phone from Shippers

--28
select manager.FirstName+' '+manager.LastName from Employees staff, Employees manager
	where staff.ReportsTo = manager.EmployeeID and 
	staff.EmployeeID in (select EmployeeID from Orders where OrderID = '10248')

--29
select ProductName, ProductID, UnitPrice from Products 
	where UnitPrice > (select avg(UnitPrice) from Products)

--30
select OrderID, sum(Quantity * UnitPrice) as Amount from [Order Details]
	group by OrderID
	having sum(Quantity * UnitPrice) > 10000

--31
select od.OrderID, o.CustomerID from [Order Details] od, Orders o
where o.OrderID = od.OrderID
	group by od.OrderID, o.CustomerID
	having sum(od.Quantity * od.UnitPrice) > 10000;

--32
select od.OrderID, o.CustomerID, c.CompanyName from [Order Details] od, Orders o, Customers c
where o.OrderID = od.OrderID and c.CustomerID = o.CustomerID
	group by od.OrderID, o.CustomerID, c.CompanyName
	having sum(od.Quantity * od.UnitPrice) > 10000;

--33
select o.CustomerID, sum(od.Quantity * od.UnitPrice) as Amount from [Order Details] od, Orders o
where od.OrderID = o.OrderID
	group by o.CustomerID order by Amount

--34
select avg(Amount / number) from [Order Details],
	(select sum(Quantity * UnitPrice) as Amount from [Order Details]) Amount,
	(select count(*) as number from Customers 
		where CustomerID in (select CustomerID from Orders)) Number

--35
select o.CustomerID, sum(od.Quantity * od.UnitPrice) as Amount from [Order Details] od, Orders o
where od.OrderID = o.OrderID
	group by o.CustomerID
	having sum(od.Quantity * od.UnitPrice) > (select avg(Amount / number) from [Order Details],
	(select sum(Quantity * UnitPrice) as Amount from [Order Details]) Amount,
	(select count(*) as number from Customers 
		where CustomerID in (select CustomerID from Orders)) Number) order by Amount


--36
select o.CustomerID, sum(od.Quantity * od.UnitPrice) as Amount from [Order Details] od, Orders o
where od.OrderID = o.OrderID and year(o.OrderDate) = '1997'
	group by o.CustomerID order by Amount