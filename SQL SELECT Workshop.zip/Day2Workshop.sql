--1a
select * from Shippers

--1b
select * from Shippers order by CompanyName

--2a
select FIrstName, LastName, Title, BirthDate, City from Employees

--2b
select distinct Title from Employees

--3
select *from orders where OrderDate = '19 May 1997'

--4a
select * from Customers where city = 'London' OR city = 'Madrid'

--4b
select * from Customers where City in ('London', 'Madrid')

--5
select CustomerID,CompanyName from Customers 
where Country='UK' order by CompanyName

--6
select OrderID,OrderDate from orders
where CustomerID ='Hanar'

--7
select TitleOfCourtesy+FirstName+' '+LastName
AS employees from Employees order by LastName ;	

--8
select OrderDate,OrderID,CustomerID from orders where CustomerID in 
(select CustomerID from Customers where CompanyName = 'Maison Dewey')
	
--9
select * from Products where ProductName LIKE '%lager%'

--10
select CustomerID, ContactName from Customers where CustomerID not in 
(select CustomerID from Orders)

--11
select AVG(UnitPrice) as AvgPrice from Products

--12
select distinct City from Customers where NOT City IS NULL

--13
select Count(distinct CustomerID) as CustomerWhoMadeOrder from Orders

--14
select CompanyName, Phone from Customers where Fax IS NULL

--15
select SUM(UnitPrice*Quantity) as TotalSales from [Order Details]

--16
select OrderID from Orders where CustomerID IN	
(select CustomerID from Customers where CompanyName IN ('Alan Out','Blone Coy'))




